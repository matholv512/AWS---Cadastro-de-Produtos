module.exports = {
  host: "localhost",
  dialect: "mysql",
  username: "root",
  password: "123",
  database: "projeto-25",
  define: {
    timestamps: true,
    underscored: true,
  },
};
